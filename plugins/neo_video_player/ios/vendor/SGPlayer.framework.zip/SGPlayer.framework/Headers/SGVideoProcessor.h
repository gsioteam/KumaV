//
//  SGVideoProcessor.h
//  SGPlayer
//
//  Created by Single on 2019/8/13.
//  Copyright © 2019 single. All rights reserved.
//

#import "SGProcessor.h"

@interface SGVideoProcessor : NSObject <SGProcessor>

@end
