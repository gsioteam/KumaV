//
//  SGAudioProcessor.h
//  SGPlayer
//
//  Created by Single on 2018/11/28.
//  Copyright © 2018 single. All rights reserved.
//

#import "SGProcessor.h"
#import "SGAudioDescriptor.h"

@interface SGAudioProcessor : NSObject <SGProcessor>

@end
